// Skill & Shelf - working JavaScript
// This file controls the Find Student and Add Skill buttons.

var skills = [
  {name:"Python", category:"Technical & IT", level:"Advanced"},
  {name:"JavaScript", category:"Technical & IT", level:"Intermediate"},
  {name:"Excel", category:"Data & Analytics", level:"Advanced"},
  {name:"Graphic Design", category:"Creative", level:"Intermediate"},
  {name:"Public Speaking", category:"Communication", level:"Advanced"},
  {name:"Leadership", category:"People & Social", level:"Intermediate"},
  {name:"Problem Solving", category:"Thinking Skills", level:"Advanced"},
  {name:"Marketing", category:"Business", level:"Beginner"},
  {name:"Telugu", category:"Languages", level:"Advanced"},
  {name:"Video Editing", category:"Creative", level:"Advanced"},
  {name:"Teamwork", category:"People & Social", level:"Advanced"},
  {name:"Time Management", category:"Personal Skills", level:"Intermediate"}
];

function get(id) {
  return document.getElementById(id);
}

function renderSkills() {
  var grid = get("skillGrid");
  if (!grid) return;

  grid.innerHTML = "";

  for (var i = 0; i < skills.length; i++) {
    var skill = skills[i];

    var card = document.createElement("div");
    card.className = "skill";

    var name = document.createElement("b");
    name.textContent = skill.name;

    var level = document.createElement("span");
    level.className = "level";
    level.textContent = skill.level;

    var category = document.createElement("small");
    category.textContent = skill.category;

    card.appendChild(name);
    card.appendChild(level);
    card.appendChild(category);
    grid.appendChild(card);
  }
}

function openProfile() {
  var profile = get("profile");
  var search = get("searchPanel");

  if (profile) {
    profile.classList.remove("hidden");
    profile.scrollIntoView({behavior:"smooth"});
  }

  if (search) {
    search.classList.add("hidden");
  }
}

function showSearch() {
  var search = get("searchPanel");
  if (search) {
    search.classList.remove("hidden");
    search.scrollIntoView({behavior:"smooth"});
  }
}

function searchStudent() {
  var input = get("studentId");
  var message = get("searchMessage");

  var id = input ? input.value.trim().toUpperCase() : "";

  if (id === "SS26-001") {
    if (message) message.textContent = "Student found ✓";
    openProfile();
  } else {
    if (message) message.textContent = "Try SS26-001 for the demo profile.";
  }
}

function openSkillModal() {
  var modal = get("skillModal");
  if (modal) {
    modal.classList.remove("hidden");

    var input = get("skillName");
    if (input) {
      setTimeout(function() {
        input.focus();
      }, 100);
    }
  }
}

function closeSkillModal() {
  var modal = get("skillModal");
  if (modal) {
    modal.classList.add("hidden");
  }
}

function addSkill() {
  var nameInput = get("skillName");
  var categoryInput = get("skillCategory");
  var levelInput = get("skillLevel");
  var message = get("skillMessage");

  if (!nameInput || !categoryInput || !levelInput) {
    alert("Skill form could not be found. Please make sure index.html and script.js are from the same final version.");
    return;
  }

  var name = nameInput.value.trim();

  if (name === "") {
    if (message) message.textContent = "Please enter a skill name.";
    nameInput.focus();
    return;
  }

  skills.unshift({
    name: name,
    category: categoryInput.value,
    level: levelInput.value
  });

  renderSkills();

  if (message) message.textContent = "Skill added successfully ✓";

  nameInput.value = "";

  setTimeout(function() {
    closeSkillModal();

    var grid = get("skillGrid");
    if (grid) {
      grid.scrollIntoView({behavior:"smooth"});
    }
  }, 400);
}

// Make the functions available to the HTML onclick buttons.
window.openProfile = openProfile;
window.showSearch = showSearch;
window.searchStudent = searchStudent;
window.openSkillModal = openSkillModal;
window.closeSkillModal = closeSkillModal;
window.addSkill = addSkill;

// Start after the page has loaded.
document.addEventListener("DOMContentLoaded", function() {
  renderSkills();
});
