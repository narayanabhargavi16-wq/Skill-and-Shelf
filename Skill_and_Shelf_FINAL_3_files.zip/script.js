const skills = [
  ["Python","Technical & IT","Advanced"],
  ["JavaScript","Technical & IT","Intermediate"],
  ["Excel","Data & Analytics","Advanced"],
  ["Graphic Design","Creative","Intermediate"],
  ["Public Speaking","Communication","Advanced"],
  ["Leadership","People & Social","Intermediate"],
  ["Problem Solving","Thinking Skills","Advanced"],
  ["Marketing","Business","Beginner"],
  ["Telugu","Languages","Advanced"],
  ["Video Editing","Creative","Advanced"],
  ["Teamwork","People & Social","Advanced"],
  ["Time Management","Personal Skills","Intermediate"]
];

function escapeHtml(value){
  return String(value)
    .replace(/&/g,"&amp;")
    .replace(/</g,"&lt;")
    .replace(/>/g,"&gt;")
    .replace(/"/g,"&quot;")
    .replace(/'/g,"&#039;");
}

function renderSkills(){
  const grid=document.getElementById("skillGrid");
  if(!grid)return;
  grid.innerHTML=skills.map(function(s){
    return '<div class="skill"><b>'+escapeHtml(s[0])+'</b><span class="level">'+escapeHtml(s[2])+'</span><small>'+escapeHtml(s[1])+'</small></div>';
  }).join("");
}

function openProfile(){
  document.getElementById("profile").classList.remove("hidden");
  document.getElementById("searchPanel").classList.add("hidden");
  document.getElementById("profile").scrollIntoView({behavior:"smooth"});
}

function showSearch(){
  const panel=document.getElementById("searchPanel");
  panel.classList.remove("hidden");
  panel.scrollIntoView({behavior:"smooth"});
}

function searchStudent(){
  const id=document.getElementById("studentId").value.trim().toUpperCase();
  const message=document.getElementById("searchMessage");
  if(id==="SS26-001"){
    message.textContent="Student found ✓";
    openProfile();
  }else{
    message.textContent="Try SS26-001 for the demo profile.";
  }
}

function openSkillModal(){
  document.getElementById("skillModal").classList.remove("hidden");
  setTimeout(function(){document.getElementById("skillName").focus();},50);
}

function closeSkillModal(){
  document.getElementById("skillModal").classList.add("hidden");
}

function addSkill(){
  const nameInput=document.getElementById("skillName");
  const categoryInput=document.getElementById("skillCategory");
  const levelInput=document.getElementById("skillLevel");
  const message=document.getElementById("skillMessage");
  const name=nameInput.value.trim();

  if(!name){
    message.textContent="Please enter a skill name.";
    nameInput.focus();
    return;
  }

  skills.unshift([name,categoryInput.value,levelInput.value]);
  renderSkills();

  message.textContent="Skill added successfully ✓";
  nameInput.value="";

  setTimeout(function(){
    closeSkillModal();
    document.getElementById("skillGrid").scrollIntoView({behavior:"smooth"});
  },500);
}

window.openProfile=openProfile;
window.showSearch=showSearch;
window.searchStudent=searchStudent;
window.openSkillModal=openSkillModal;
window.closeSkillModal=closeSkillModal;
window.addSkill=addSkill;

document.addEventListener("DOMContentLoaded",renderSkills);
